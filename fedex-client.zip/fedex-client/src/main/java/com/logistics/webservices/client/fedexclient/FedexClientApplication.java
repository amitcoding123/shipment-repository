package com.logistics.webservices.client.fedexclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FedexClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(FedexClientApplication.class, args);
	}

}
