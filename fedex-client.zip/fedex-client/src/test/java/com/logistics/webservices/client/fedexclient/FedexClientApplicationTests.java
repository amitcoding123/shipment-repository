package com.logistics.webservices.client.fedexclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FedexClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
